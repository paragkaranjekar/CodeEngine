#include <iostream>
#include <thread>
#include <chrono>
#include <cstring>
#include <sys/socket.h>
#include <sys/un.h>
#include <unistd.h>
#include <iomanip>
#include <sstream>
#include <chrono>
#include <string>
#include <iostream>
#include <sys/socket.h>
#include <sys/un.h>
#include <unistd.h>
#include <algorithm>

// Include the IDL-generated types (from `idlc -l c vss_topics.idl`)
extern "C" {
#include "vss_topics.h"
}

#include "dds/dds.h"

// -----------------------------------------------------------------------------
// DDS Topic Names
// -----------------------------------------------------------------------------
#define VISS_REQ_TOPIC "VISSRequest"
#define VISS_RES_TOPIC "VISSResponse"
#define VSS_DATA_TOPIC   "VehicleData"

// -----------------------------------------------------------------------------
// IPC Helpers
// -----------------------------------------------------------------------------
std::string ipc_request(const std::string &request)
{

    const char *socket_path = "/tmp/vss_ipc_socket";
    int sock = socket(AF_UNIX, SOCK_STREAM, 0);
    if (sock < 0) {
        perror("socket");
        return "{}";
    }

    sockaddr_un addr{};
    addr.sun_family = AF_UNIX;
    strncpy(addr.sun_path, socket_path, sizeof(addr.sun_path) - 1);

    int attempts = 10;
	while (connect(sock, (sockaddr *)&addr, sizeof(addr)) < 0 && attempts-- > 0) {
	    std::this_thread::sleep_for(std::chrono::milliseconds(200));
	}
	if (attempts <= 0) {
	    perror("connect");
	    close(sock);
	    return "{}";
	}


    write(sock, request.c_str(), request.size());
    char buffer[65536];
    ssize_t n = read(sock, buffer, sizeof(buffer) - 1);
    close(sock);

    if (n > 0) {
        buffer[n] = '\0';
        return std::string(buffer);
    }
    return "{}";
}

// -----------------------------------------------------------------------------
// DDS Schema Request Handler
// -----------------------------------------------------------------------------
void dds_viss_get(dds_entity_t participant)
{
    // Create VISSRequest topic + reader
    dds_entity_t req_topic = dds_create_topic(
        participant, &VISSRequest_desc, VISS_REQ_TOPIC, nullptr, nullptr);
    dds_entity_t req_reader = dds_create_reader(participant, req_topic, nullptr, nullptr);

    // Create VISSResponse topic + writer
    dds_entity_t res_topic = dds_create_topic(
        participant, &VISSResponse_desc, VISS_RES_TOPIC, nullptr, nullptr);
    dds_entity_t res_writer = dds_create_writer(participant, res_topic, nullptr, nullptr);

     std::cout << "[DDS] Waiting for VISS GET requests...\n";

    while (true) {
        VISSRequest req{};
        void* samples[1] = { &req };
        dds_sample_info_t info;
        dds_return_t rc = dds_take(req_reader, samples, &info, 1, 1);

        if (rc > 0 && info.valid_data) {

            std::string request(req.json);
            std::cout << "[DDS] GET Request payload: " << request << std::endl;

            // -------------------------------------------------
            // Extract "path" from the incoming JSON
            // Format:
            //   {"action":"get","path":"Vehicle.Speed","requestId":"123"}
            // -------------------------------------------------
            std::string path = "UNKNOWN";
            size_t p1 = request.find("\"path\"");
            if (p1 != std::string::npos) {
                size_t q1 = request.find("\"", p1 + 6);
                size_t q2 = request.find("\"", q1 + 1);
                if (q1 != std::string::npos && q2 != std::string::npos)
                    path = request.substr(q1 + 1, q2 - q1 - 1);
            }

            std::cout << "[DDS] Path: " << path << std::endl;

            // -------------------------------------------------
            // Ask DataBroker for the latest value via IPC
            // -------------------------------------------------
            std::string ipcResponse = ipc_request("GET " + path);

            // Expected from broker:  "<value>|<timestamp>"
            std::string value = "0";
            std::string timestamp = "1970-01-01T00:00:00Z";

            size_t sep = ipcResponse.find('|');
            if (sep != std::string::npos) {
                value = ipcResponse.substr(0, sep);
                timestamp = ipcResponse.substr(sep + 1);
            }

            // -------------------------------------------------
            // Build VISS response JSON
            // -------------------------------------------------
            std::string jsonResponse =
                "{"
                "\"action\":\"get\","
                "\"path\":\"" + path + "\","
                "\"value\":" + value + ","
                "\"timestamp\":\"" + timestamp + "\""
                "}";

            // -------------------------------------------------
            // Publish VISSResponse
            // -------------------------------------------------
            VISSResponse res{};
            strncpy(res.json, jsonResponse.c_str(), sizeof(res.json) - 1);

            dds_write(res_writer, &res);

            std::cout << "[DDS] Sent GET response: " << jsonResponse << std::endl;
        }

        std::this_thread::sleep_for(std::chrono::milliseconds(100));
    }
}

//------------------------set function ---------------------------------------

void dds_viss_set(dds_entity_t participant)
{
    // Create VISSRequest topic + reader
    dds_entity_t req_topic = dds_create_topic(
        participant, &VISSRequest_desc, VISS_REQ_TOPIC, nullptr, nullptr);
    dds_entity_t req_reader = dds_create_reader(participant, req_topic, nullptr, nullptr);

    // Create VISSResponse topic + writer
    dds_entity_t res_topic = dds_create_topic(
        participant, &VISSResponse_desc, VISS_RES_TOPIC, nullptr, nullptr);
    dds_entity_t res_writer = dds_create_writer(participant, res_topic, nullptr, nullptr);

    std::cout << "[DDS] Waiting for VISS SET requests...\n";

    while (true) {

        VISSRequest req{};
        void* samples[1] = { &req };
        dds_sample_info_t info{};
        dds_return_t rc = dds_take(req_reader, samples, &info, 1, 1);

        if (rc > 0 && info.valid_data) {

            std::string request(req.json);
            std::cout << "[DDS] SET Request payload: " << request << std::endl;

            // -------------------------------------------------
            // Parse JSON manually (same as GET)
            // Format:
            // {"action":"set","path":"Vehicle.Speed","value":50,"requestId":"123"}
            // -------------------------------------------------

            // Extract path
            std::string path = "UNKNOWN";
            size_t p1 = request.find("\"path\"");
            if (p1 != std::string::npos) {
                size_t q1 = request.find("\"", p1 + 6);
                size_t q2 = request.find("\"", q1 + 1);
                if (q1 != std::string::npos && q2 != std::string::npos)
                    path = request.substr(q1 + 1, q2 - q1 - 1);
            }

            // Extract value (NUMBER)
            double value = 0.0;
            size_t vpos = request.find("\"value\"");
            if (vpos != std::string::npos) {
                size_t colon = request.find(":", vpos);
                if (colon != std::string::npos)
                    value = atof(request.substr(colon + 1).c_str());
            }

            std::cout << "[DDS] Path : " << path  << std::endl;
            std::cout << "[DDS] Value: " << value << std::endl;

            // -------------------------------------------------
            // Send SET to IPC:  "SET <path> <value>"
            // Broker should return: "OK|<timestamp>" or "ERR"
            // -------------------------------------------------
            std::string ipcResponse = ipc_request(
                "SET " + path + " " + std::to_string(value));

            std::string status = "OK";
            std::string timestamp = "1970-01-01T00:00:00Z";

            size_t sep = ipcResponse.find('|');
            if (sep != std::string::npos) {
                status = ipcResponse.substr(0, sep);
                timestamp = ipcResponse.substr(sep + 1);
            }

            // -------------------------------------------------
            // Build VISS SET RESPONSE
            // -------------------------------------------------
            std::string jsonResponse =
                "{"
                    "\"action\":\"set\","
                    "\"path\":\"" + path + "\","
                    "\"value\":" + std::to_string(value) + ","
                    "\"timestamp\":\"" + timestamp + "\","
                    "\"status\":\"" + status + "\""
                "}";

            // -------------------------------------------------
            // Publish response
            // -------------------------------------------------
            VISSResponse res{};
            strncpy(res.json, jsonResponse.c_str(), sizeof(res.json) - 1);
            dds_write(res_writer, &res);

            std::cout << "[DDS] Sent SET response: " << jsonResponse << std::endl;
        }

        std::this_thread::sleep_for(std::chrono::milliseconds(100));
    }
}

//---------------------sub---------------------------------------------

void dds_viss_subscribe(dds_entity_t participant)
{
    // Same as GET/SET
    dds_entity_t req_topic = dds_create_topic(
        participant, &VISSRequest_desc, VISS_REQ_TOPIC, nullptr, nullptr);
    dds_entity_t req_reader = dds_create_reader(participant, req_topic, nullptr, nullptr);

    dds_entity_t res_topic = dds_create_topic(
        participant, &VISSResponse_desc, VISS_RES_TOPIC, nullptr, nullptr);
    dds_entity_t res_writer = dds_create_writer(participant, res_topic, nullptr, nullptr);

    std::cout << "[DDS] Waiting for VISS SUBSCRIBE requests...\n";

    while (true) {

        VISSRequest req{};
        void* samples[1] = { &req };
        dds_sample_info_t info{};
        dds_return_t rc = dds_take(req_reader, samples, &info, 1, 1);

        if (rc > 0 && info.valid_data)
        {
            std::string request(req.json);
            if (request.find("\"action\":\"subscribe\"") == std::string::npos)
                continue;

            std::cout << "[DDS] SUBSCRIBE Request: " << request << std::endl;

            // -------------------------
            // Extract path
            // -------------------------
            std::string path = "UNKNOWN";
            size_t p1 = request.find("\"path\"");
            if (p1 != std::string::npos) {
                size_t q1 = request.find("\"", p1 + 6);
                size_t q2 = request.find("\"", q1 + 1);
                if (q2 != std::string::npos)
                    path = request.substr(q1 + 1, q2 - q1 - 1);
            }

            // -------------------------
            // Extract interval
            // -------------------------
            int interval = 1000;  // default 1 second
            size_t f1 = request.find("\"interval\"");
            if (f1 != std::string::npos) {
                size_t colon = request.find(":", f1);
                if (colon != std::string::npos)
                    interval = atoi(request.substr(colon + 1).c_str());
            }

            std::cout << "[DDS] Subscribe path = " << path
                      << ", interval = " << interval << std::endl;

            // -------------------------
            // Send to IPC
            // -------------------------
            std::string ipcResponse = ipc_request(
                "SUB " + path + " " + std::to_string(interval));

            // IPC expected: subscriptionId
            std::string subscriptionId = ipcResponse;
            subscriptionId.erase(
                std::remove(subscriptionId.begin(), subscriptionId.end(), '\n'),
                subscriptionId.end());

            // -------------------------
            // Build VISS response
            // -------------------------
            std::string response =
                "{"
                "\"action\":\"subscribe\","
                "\"subscriptionId\":\"" + subscriptionId + "\""
                "}";

            // -------------------------
            // Publish VISSResponse
            // -------------------------
            VISSResponse res{};
            strncpy(res.json, response.c_str(), sizeof(res.json) - 1);
            dds_write(res_writer, &res);

            std::cout << "[DDS] Sent SUBSCRIBE response: " << response << std::endl;
        }

        std::this_thread::sleep_for(std::chrono::milliseconds(80));
    }
}

//-------------------unsub------------------------------------------------

void dds_viss_unsubscribe(dds_entity_t participant)
{
    dds_entity_t req_topic = dds_create_topic(
        participant, &VISSRequest_desc, VISS_REQ_TOPIC, nullptr, nullptr);
    dds_entity_t req_reader = dds_create_reader(participant, req_topic, nullptr, nullptr);

    dds_entity_t res_topic = dds_create_topic(
        participant, &VISSResponse_desc, VISS_RES_TOPIC, nullptr, nullptr);
    dds_entity_t res_writer = dds_create_writer(participant, res_topic, nullptr, nullptr);

    std::cout << "[DDS] Waiting for VISS UNSUBSCRIBE requests...\n";

    while (true) {

        VISSRequest req{};
        void* samples[1] = { &req };
        dds_sample_info_t info{};
        dds_return_t rc = dds_take(req_reader, samples, &info, 1, 1);

        if (rc > 0 && info.valid_data)
        {
            std::string request(req.json);

            if (request.find("\"action\":\"unsubscribe\"") == std::string::npos)
                continue;

            std::cout << "[DDS] UNSUBSCRIBE Request: " << request << std::endl;

            // ---------------------------------
            // Extract subscriptionId
            // ---------------------------------
            std::string subId = "UNKNOWN";
            size_t s1 = request.find("\"subscriptionId\"");
            if (s1 != std::string::npos) {
                size_t q1 = request.find("\"", s1 + 17);
                size_t q2 = request.find("\"", q1 + 1);
                if (q2 != std::string::npos)
                    subId = request.substr(q1 + 1, q2 - q1 - 1);
            }

            // ---------------------------------
            // IPC: UNSUB <subscriptionId>
            // ---------------------------------
            std::string ipcResponse = ipc_request("UNSUB " + subId);

            std::string status = ipcResponse;
            status.erase(
                std::remove(status.begin(), status.end(), '\n'),
                status.end());

            // ---------------------------------
            // Build response
            // ---------------------------------
            std::string response =
                "{"
                "\"action\":\"unsubscribe\","
                "\"subscriptionId\":\"" + subId + "\","
                "\"status\":\"" + status + "\""
                "}";

            // ---------------------------------
            // Send response
            // ---------------------------------
            VISSResponse res{};
            strncpy(res.json, response.c_str(), sizeof(res.json) - 1);
            dds_write(res_writer, &res);

            std::cout << "[DDS] Sent UNSUBSCRIBE response: " << response << std::endl;
        }

        std::this_thread::sleep_for(std::chrono::milliseconds(80));
    }
}


// -----------------------------------------------------------------------------
// MAIN
// -----------------------------------------------------------------------------
int main()
{
    std::cout << "[Terminal 1] Starting VSS DDS Bridge...\n";

    dds_entity_t participant = dds_create_participant(DDS_DOMAIN_DEFAULT, nullptr, nullptr);
    if (participant < 0) {
        std::cerr << "Failed to create DDS participant.\n";
        return 1;
    }
    
std::thread tGet(dds_viss_get, participant);
std::thread tSet(dds_viss_set, participant);
std::thread tSub(dds_viss_subscribe, participant);
std::thread tUnSub(dds_viss_unsubscribe, participant);

tGet.join();
tSet.join();
tSub.join();
tUnSub.join();

    dds_delete(participant);
    return 0;
}

