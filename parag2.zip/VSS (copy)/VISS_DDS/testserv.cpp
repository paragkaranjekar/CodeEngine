#include <iostream>
#include <string>
#include <sys/socket.h>
#include <sys/un.h>
#include <unistd.h>
#include <thread>
#include <cstring>

#define IPC_SOCKET_PATH "/tmp/vss_ipc_socket"

// --------------------------------------
// Fake data for testing
// --------------------------------------
std::string fake_get_response(const std::string& path) {
    // Your DDS GET expects   "<value>|<timestamp>"
    return "42.5|2025-01-01T10:00:00.000Z";
}

std::string fake_set_response(const std::string& path, const std::string& value) {
    // Your DDS SET expects JSON
    return "ok|2025-01-01T10:00:00.000Z";
}

std::string fake_schema_response(const std::string& prefix) {
    return "{ \"Vehicle\": { \"Speed\": {} } }";
}

std::string fake_subscribe_response(const std::string& path) {
    // Your subscribe DDS handler expects this
    return "SUB_TEST_001";
}

std::string fake_unsubscribe_response(const std::string& id) {
    return "unsub_test";
}

// ----------------------------------------------------
// Handle a single client request
// ----------------------------------------------------
void handle_client(int clientSock)
{
    char buffer[2048];
    ssize_t n = read(clientSock, buffer, sizeof(buffer)-1);

    if (n <= 0) {
        close(clientSock);
        return;
    }

    buffer[n] = '\0';
    std::string req(buffer);

    std::cout << "[IPC] Received: " << req << std::endl;

    std::string reply = "{}";

    // ----------------------------------------------------
    // GET
    // Format expected:  "GET <path>"
    // ----------------------------------------------------
    if (req.rfind("GET ", 0) == 0) {
        std::string path = req.substr(4);
        reply = fake_get_response(path);
    }

    // ----------------------------------------------------
    // SET
    // Format: "SET <path> <value>"
    // ----------------------------------------------------
    else if (req.rfind("SET ", 0) == 0) {
        std::string rest = req.substr(4);
        size_t sp = rest.find(' ');
        if (sp != std::string::npos) {
            std::string path  = rest.substr(0, sp);
            std::string value = rest.substr(sp + 1);
            reply = fake_set_response(path, value);
        }
    }

    // ----------------------------------------------------
    // SCHEMA
    // Format: "GET_SCHEMA <prefix>"
    // ----------------------------------------------------
    else if (req.rfind("GET_SCHEMA ", 0) == 0) {
        std::string prefix = req.substr(11);
        reply = fake_schema_response(prefix);
    }

    // ----------------------------------------------------
    // SUBSCRIBE
    // Format: "SUB <path>"
    // ----------------------------------------------------
    else if (req.rfind("SUB ", 0) == 0) {
        std::string path = req.substr(4);
        reply = fake_subscribe_response(path);
    }

    // ----------------------------------------------------
    // UNSUBSCRIBE
    // Format: "UNSUB <subscriptionId>"
    // ----------------------------------------------------
    else if (req.rfind("UNSUB ", 0) == 0) {
        std::string id = req.substr(6);
        reply = fake_unsubscribe_response(id);
    }

    // ----------------------------------------------------
    // Send back reply
    // ----------------------------------------------------
    write(clientSock, reply.c_str(), reply.size());
    close(clientSock);

    std::cout << "[IPC] Replied: " << reply << std::endl;
}


// ----------------------------------------------------
// Main IPC Server
// ----------------------------------------------------
int main()
{
    unlink(IPC_SOCKET_PATH);

    int serverSock = socket(AF_UNIX, SOCK_STREAM, 0);
    if (serverSock < 0) {
        perror("socket");
        return 1;
    }

    sockaddr_un addr{};
    addr.sun_family = AF_UNIX;
    strncpy(addr.sun_path, IPC_SOCKET_PATH, sizeof(addr.sun_path)-1);

    if (bind(serverSock, (sockaddr*)&addr, sizeof(addr)) < 0) {
        perror("bind");
        close(serverSock);
        return 1;
    }

    if (listen(serverSock, 5) < 0) {
        perror("listen");
        close(serverSock);
        return 1;
    }

    std::cout << "[IPC SERVER] Listening at " << IPC_SOCKET_PATH << std::endl;

    // Accept clients forever
    while (true) {
        int client = accept(serverSock, nullptr, nullptr);
        if (client >= 0) {
            std::thread(handle_client, client).detach();
        }
    }

    close(serverSock);
    return 0;
}
