#ifndef SQLITE_DB_HPP
#define SQLITE_DB_HPP

#include <sqlite3.h>
#include <cjson/cJSON.h>
#include <string>
#include <vector>
#include <map>
#include <mutex>
#include <thread>
#include <atomic>
#include <chrono>
#include <algorithm>
#include <sstream>
#include <iostream>
#include <filesystem>

struct TimeSeriesPoint {
    std::string iso_timestamp;
    double value;
};

class SQLiteDB {
private:
    sqlite3* db = nullptr;

    std::mutex dbMutex;
    std::mutex bufferMutex;

    std::map<std::string, int> nodeMap;
    std::map<int, std::vector<TimeSeriesPoint>> buffer;

    std::atomic<bool> flushThreadRunning{false};
    std::thread flushThread;

public:

    // ================================================================
    //               INIT (create DB & schema if missing)
    // ================================================================
    bool init(const std::string &dbFile, unsigned flushIntervalSec = 2)
    {
        bool dbAlreadyExists = std::filesystem::exists(dbFile);

        // 1. Open DB
        {
            std::lock_guard<std::mutex> lock(dbMutex);
            if (sqlite3_open(dbFile.c_str(), &db) != SQLITE_OK) {
                std::cerr << "[SQLiteDB] Failed to open DB: "
                          << sqlite3_errmsg(db) << "\n";
                return false;
            }
        }

        // 2. If database file did NOT exist → CREATE schema
        if (!dbAlreadyExists) {
            std::cout << "[SQLiteDB] Creating new DB schema…\n";
            createSchema();
        }

        // 3. Load node IDs
        loadNodeIds();

        // 4. Start background flush thread
        flushThreadRunning = true;
        flushThread = std::thread(&SQLiteDB::flushLoop, this, flushIntervalSec);

        return true;
    }

    // ================================================================
    //             DESTRUCTOR (save & shutdown cleanly)
    // ================================================================
    ~SQLiteDB() {
        stopFlushThread();
        flush();
        if (db) sqlite3_close(db);
    }

    // ================================================================
    //                    ADD VSS SAMPLE
    // ================================================================
    void add_vss_sample(const std::string &path,
                    double value,
                    const std::string &isoTs)
	{
	    int nodeId = -1;

	    {
		std::lock_guard<std::mutex> lock(dbMutex);

		auto it = nodeMap.find(path);

		if (it == nodeMap.end()) {
		    // --- auto-create node ---
		    const char* insertSQL =
		        "INSERT INTO nodes(full_path) VALUES(?);";

		    sqlite3_stmt* stmt = nullptr;
		    if (sqlite3_prepare_v2(db, insertSQL, -1, &stmt, nullptr) == SQLITE_OK) {
		        sqlite3_bind_text(stmt, 1, path.c_str(), -1, SQLITE_TRANSIENT);
		        sqlite3_step(stmt);
		    }
		    sqlite3_finalize(stmt);

		    // fetch new ID
		    nodeId = (int)sqlite3_last_insert_rowid(db);
		    nodeMap[path] = nodeId;

		    std::cout << "[SQLiteDB] Added new VSS node: "
		              << path << " (id=" << nodeId << ")\n";
		} 
		else {
		    nodeId = it->second;
		}
	    }

	    // --- Store in buffer ---
	    std::lock_guard<std::mutex> lock(bufferMutex);
	    buffer[nodeId].push_back({isoTs, value});
	}


    // ================================================================
    //                    QUERY LATEST VALUE
    // ================================================================
    TimeSeriesPoint get_latest(const std::string &path)
    {
        TimeSeriesPoint res{"", 0.0};

        std::lock_guard<std::mutex> lock(dbMutex);

        const char* sql =
            "SELECT t.timestamp_iso, t.value "
            "FROM timeseries t "
            "JOIN nodes n ON n.id = t.node_id "
            "WHERE n.full_path = ? "
            "ORDER BY t.timestamp_iso DESC LIMIT 1;";

        sqlite3_stmt* stmt = nullptr;

        if (sqlite3_prepare_v2(db, sql, -1, &stmt, nullptr) == SQLITE_OK) {
            sqlite3_bind_text(stmt, 1, path.c_str(), -1, SQLITE_TRANSIENT);

            if (sqlite3_step(stmt) == SQLITE_ROW) {
                const char* ts = (const char*)sqlite3_column_text(stmt, 0);
                double val     = sqlite3_column_double(stmt, 1);
                res = { ts ? ts : "", val };
            }
        }
        sqlite3_finalize(stmt);
        return res;
    }

    // ================================================================
    //                    QUERY TIMESERIES
    // ================================================================
    std::vector<TimeSeriesPoint> get_timeseries(
        const std::string &path, size_t limit = 100)
    {
        std::vector<TimeSeriesPoint> out;

        std::lock_guard<std::mutex> lock(dbMutex);

        const char* sql =
            "SELECT t.timestamp_iso, t.value "
            "FROM timeseries t "
            "JOIN nodes n ON n.id = t.node_id "
            "WHERE n.full_path = ? "
            "ORDER BY t.timestamp_iso DESC "
            "LIMIT ?;";

        sqlite3_stmt* stmt = nullptr;

        if (sqlite3_prepare_v2(db, sql, -1, &stmt, nullptr) == SQLITE_OK)
        {
            sqlite3_bind_text(stmt, 1, path.c_str(), -1, SQLITE_TRANSIENT);
            sqlite3_bind_int(stmt, 2, (int)limit);

            while (sqlite3_step(stmt) == SQLITE_ROW) {
                const char* ts = (const char*)sqlite3_column_text(stmt, 0);
                double value   = sqlite3_column_double(stmt, 1);

                out.push_back({ ts ? ts : "", value });
            }
        }
        sqlite3_finalize(stmt);
        return out;
    }

    // ================================================================
    //                 HIERARCHICAL SCHEMA → JSON
    // ================================================================
    std::string get_schema_json(const std::string &prefix)
    {
        std::lock_guard<std::mutex> lock(dbMutex);

        std::string query =
            "SELECT full_path FROM nodes WHERE full_path LIKE '" +
            prefix + "%';";

        sqlite3_stmt* stmt = nullptr;
        sqlite3_prepare_v2(db, query.c_str(), -1, &stmt, nullptr);

        cJSON* root = cJSON_CreateObject();

        while (sqlite3_step(stmt) == SQLITE_ROW)
        {
            const char* path = (const char*)sqlite3_column_text(stmt, 0);
            if (!path) continue;

            std::string rel = path;
            if (rel.rfind(prefix, 0) == 0)
                rel = rel.substr(prefix.size());

            if (!rel.empty() && rel[0] == '.')
                rel.erase(0, 1);

            std::stringstream ss(rel);
            std::string seg;
            cJSON* node = root;

            while (std::getline(ss, seg, '.')) {
                if (seg.empty()) continue;

                cJSON* next = cJSON_GetObjectItem(node, seg.c_str());
                if (!next) {
                    next = cJSON_CreateObject();
                    cJSON_AddItemToObject(node, seg.c_str(), next);
                }
                node = next;
            }
        }

        sqlite3_finalize(stmt);

        char* json = cJSON_PrintUnformatted(root);
        std::string out = json;
        cJSON_free(json);
        cJSON_Delete(root);

        return out;
    }

private:

    // ================================================================
    //                   CREATE SCHEMA (first run)
    // ================================================================
    void createSchema()
    {
        const char* nodesSQL =
            "CREATE TABLE IF NOT EXISTS nodes ("
            "  id INTEGER PRIMARY KEY AUTOINCREMENT,"
            "  full_path TEXT UNIQUE NOT NULL"
            ");";

        const char* tsSQL =
            "CREATE TABLE IF NOT EXISTS timeseries ("
            "  id INTEGER PRIMARY KEY AUTOINCREMENT,"
            "  node_id INTEGER,"
            "  vss_path TEXT,"
            "  timestamp_iso TEXT,"
            "  value REAL,"
            "  FOREIGN KEY(node_id) REFERENCES nodes(id)"
            ");";

        sqlite3_exec(db, nodesSQL, nullptr, nullptr, nullptr);
        sqlite3_exec(db, tsSQL,   nullptr, nullptr, nullptr);

        std::cout << "[SQLiteDB] Schema created.\n";
    }

    // ================================================================
    //                 Load node IDs into nodeMap
    // ================================================================
    void loadNodeIds()
    {
        std::lock_guard<std::mutex> lock(dbMutex);

        nodeMap.clear();
        const char* sql = "SELECT id, full_path FROM nodes;";
        sqlite3_stmt* stmt = nullptr;

        if (sqlite3_prepare_v2(db, sql, -1, &stmt, nullptr) == SQLITE_OK)
        {
            while (sqlite3_step(stmt) == SQLITE_ROW)
            {
                int id = sqlite3_column_int(stmt, 0);
                const char* p = (const char*)sqlite3_column_text(stmt, 1);
                if (p) nodeMap[p] = id;
            }
        }
        sqlite3_finalize(stmt);
    }

    // ================================================================
    //                   FLUSH BUFFER TO DB
    // ================================================================
    void flush()
    {
        std::map<int, std::vector<TimeSeriesPoint>> local;

        {
            std::lock_guard<std::mutex> lock(bufferMutex);
            if (buffer.empty()) return;
            buffer.swap(local);
        }

        std::lock_guard<std::mutex> lock(dbMutex);
        sqlite3_exec(db, "BEGIN TRANSACTION;", nullptr, nullptr, nullptr);

        for (auto &pair : local) {
            int nodeId = pair.first;
            auto &points = pair.second;

            if (points.size() > 3) {
                points = std::vector<TimeSeriesPoint>(
                    points.end() - 3,
                    points.end()
                );
            }

            std::string path = "<unknown>";
            for (auto &p : nodeMap)
                if (p.second == nodeId)
                    path = p.first;

            const char* sql =
                "INSERT INTO timeseries(node_id, vss_path, timestamp_iso, value)"
                "VALUES(?, ?, ?, ?);";

            for (auto &pt : points) {
                sqlite3_stmt* stmt = nullptr;
                if (sqlite3_prepare_v2(db, sql, -1, &stmt, nullptr) == SQLITE_OK)
                {
                    sqlite3_bind_int(stmt, 1, nodeId);
                    sqlite3_bind_text(stmt, 2, path.c_str(), -1, SQLITE_TRANSIENT);
                    sqlite3_bind_text(stmt, 3, pt.iso_timestamp.c_str(), -1, SQLITE_TRANSIENT);
                    sqlite3_bind_double(stmt, 4, pt.value);

                    sqlite3_step(stmt);
                }
                sqlite3_finalize(stmt);
            }
        }

        sqlite3_exec(db, "COMMIT;", nullptr, nullptr, nullptr);
    }

    // ================================================================
    //               Background flushing thread
    // ================================================================
    void flushLoop(unsigned sec)
    {
        while (flushThreadRunning.load()) {
            std::this_thread::sleep_for(std::chrono::seconds(sec));
            flush();
        }
    }

    void stopFlushThread()
    {
        flushThreadRunning = false;
        if (flushThread.joinable()) flushThread.join();
    }
};

#endif // SQLITE_DB_HPP

