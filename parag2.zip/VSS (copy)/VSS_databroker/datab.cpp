// main.cpp
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <cstring>
#include <chrono>
#include <thread>
#include <iomanip>
#include <sys/socket.h>
#include <sys/un.h>
#include <unistd.h>
#include <sys/types.h>
#include <cstdlib>
#include <cerrno>

#include "include/mappings.h"
#include "include/sqlite-db.hpp"   // your header-only SQLiteDB

SQLiteDB db;

using namespace std;

enum DataType : uint8_t { DT_UINT8, DT_UINT16, DT_FLOAT };

// RawData struct exactly like your main program
typedef struct {
    uint16_t service_id;
    uint16_t event_id;
    size_t payload_len;
    uint8_t payload[256];
    uint64_t timestamp_ms;
} RawData;


// ---------------------------- Helpers ----------------------------

inline DataType dtypeToEnum(const char* dtype) {
    if (strcmp(dtype, "uint8") == 0) return DT_UINT8;
    if (strcmp(dtype, "uint16") == 0) return DT_UINT16;
    if (strcmp(dtype, "float") == 0) return DT_FLOAT;
    return DT_UINT8;
}

inline uint16_t be16(uint16_t v) {
    return __builtin_bswap16(v);
}

// Convert ms timestamp → ISO8601 UTC
string toISO8601(uint64_t ms_since_epoch) {
    using namespace std::chrono;
    milliseconds ms(ms_since_epoch);
    system_clock::time_point tp(ms);

    time_t tt = system_clock::to_time_t(tp);
    std::tm tm_utc{};
#if defined(_WIN32)
    gmtime_s(&tm_utc, &tt);
#else
    gmtime_r(&tt, &tm_utc);
#endif

    long ms_part = ms_since_epoch % 1000;

    std::ostringstream oss;
    oss << std::put_time(&tm_utc, "%Y-%m-%dT%H:%M:%S")
        << "." << std::setw(3) << std::setfill('0') << ms_part
        << "Z";

    return oss.str();
}

string nowISO8601() {
    using namespace std::chrono;
    auto now = duration_cast<milliseconds>(system_clock::now().time_since_epoch()).count();
    return toISO8601((uint64_t)now);
}

// --------------------- Start Kuzu service (fork + execl) -------------------
void start_kuzu_service() {
    pid_t pid = fork();

    if (pid == 0) {
        // CHILD PROCESS
        // executable path relative to working dir
        execl("./build/kuzu-cpp", "kuzu-cpp", (char*)NULL);

        // only reached on failure
        perror("Failed to start kuzu_service (execl)");
        _exit(1);
    }
    else if (pid > 0) {
        // PARENT PROCESS
        printf("[VSS] KuzuService started in background (PID=%d)\n", pid);
    }
    else {
        perror("fork failed!");
    }
}

// ---------------------------- Send to kuzu ----------------------------
// Connects and sends: "<path>|<value>|<ISO>"
void send_to_kuzu(const string &path, double val, const string &ts) {
    const char *sockPath = "/tmp/kuzu_vss.sock";
    int sock = socket(AF_UNIX, SOCK_STREAM, 0);
    if (sock < 0) {
        perror("[send_to_kuzu] socket");
        return;
    }

    sockaddr_un addr{};
    addr.sun_family = AF_UNIX;
    strncpy(addr.sun_path, sockPath, sizeof(addr.sun_path)-1);

    // simple retry loop to increase reliability
    int attempts = 5;
    while (attempts-- > 0) {
        if (connect(sock, (sockaddr*)&addr, sizeof(addr)) == 0) break;
        std::this_thread::sleep_for(std::chrono::milliseconds(200));
    }

    if (errno != 0 && attempts < 0) {
        // could not connect
        close(sock);
        return;
    }

    string msg = path + "|" + to_string(val) + "|" + ts;
    ssize_t written = write(sock, msg.c_str(), msg.size());
    (void)written;
    close(sock);
}


// ---------------------------- Mapping Lookup ----------------------------

const MappingEntry* findMapping(uint16_t sid, uint16_t eid) {
    int low = 0, high = MAPPING_TABLE_SIZE - 1;

    while (low <= high) {
        int mid = (low + high) >> 1;

        auto msid = mappingTable[mid].service_id;
        auto meid = mappingTable[mid].method_id;

        if ((msid < sid) || (msid == sid && meid < eid))
            low = mid + 1;
        else if ((msid > sid) || (msid == sid && meid > eid))
            high = mid - 1;
        else
            return &mappingTable[mid];
    }
    return nullptr;
}

// ---------------------------- Raw Data Processor ----------------------------

string processRawData(const RawData &data)
{
    string out;

    const MappingEntry* m = findMapping(data.service_id, data.event_id);
    if (!m) {
        out += "NO MAPPING FOR SID=0x" + to_string(data.service_id) +
               " EID=0x" + to_string(data.event_id) + "\n";
        return out;
    }

    string iso = toISO8601(data.timestamp_ms);

    for (size_t i = 0; i < m->num_signals; i++) {
        const MappingSignal &sig = m->signals[i];

        double value = 0;

        switch (dtypeToEnum(sig.dtype)) {
            case DT_UINT8:
                value = data.payload[sig.offset];
                break;

            case DT_UINT16: {
                // guard bounds
                uint16_t hi = data.payload[sig.offset];
                uint16_t lo = data.payload[sig.offset + 1];
                uint16_t raw = (hi << 8) | lo;
                value = raw;
                break;
            }

            case DT_FLOAT: {
                float raw = 0.0f;
                memcpy(&raw, &data.payload[sig.offset], sizeof(raw));
                value = raw;
                break;
            }
        }

        value *= sig.scaling;

        out += string(sig.vss_path) + " = " +
               to_string(value) + " " +
               sig.unit + " @ " + iso + "\n";

        // send to kuzu and add to sqlite buffer
        send_to_kuzu(sig.vss_path, value, iso);
        db.add_vss_sample(sig.vss_path, value, iso);
    }

    return out;
}

// ---------------------------- Middleware Function ----------------------------

void Middleware_someipreq(const RawData &data)
{
    string converted = processRawData(data);
    (void)converted; // keep behavior same (not printing by default)
}


// ---------------------------- Input Line Parser ----------------------------
// INPUT FORMAT EXAMPLE:
// 0x1234,0x0001,0170 017A 0164 0174,18100

bool parseLine(const string& line, RawData &data)
{
    if (line.empty() || line[0]=='#') return false;

    string sid_str, eid_str, words_str, ts_str;

    stringstream ss(line);
    getline(ss, sid_str, ',');
    getline(ss, eid_str, ',');
    getline(ss, words_str, ',');
    getline(ss, ts_str);

    // allow trimming spaces
    auto trim = [](string s) {
        size_t a = s.find_first_not_of(" \t\r\n");
        if (a==string::npos) return string();
        size_t b = s.find_last_not_of(" \t\r\n");
        return s.substr(a, b - a + 1);
    };

    sid_str = trim(sid_str);
    eid_str = trim(eid_str);
    words_str = trim(words_str);
    ts_str = trim(ts_str);

    data.service_id = (uint16_t)stoi(sid_str, nullptr, 16);
    data.event_id = (uint16_t)stoi(eid_str, nullptr, 16);
    data.timestamp_ms = (uint64_t)stoull(ts_str);

    // Parse 16-bit words into payload
    data.payload_len = 0;

    stringstream ws(words_str);
    string word;
    while (ws >> word) {
        uint16_t val = (uint16_t)stoi(word, nullptr, 16);
        if (data.payload_len + 1 < sizeof(data.payload)) {
            data.payload[data.payload_len++] = (val >> 8) & 0xFF;
            data.payload[data.payload_len++] = val & 0xFF;
        } else break;
    }

    return true;
}


// ---------------------- receive kuzu JSON reply (keeps listening) ----------------------------
void receive_kuzu_json() {
    const char* sock_path = "/tmp/kuzu_vss_reply.sock";
    unlink(sock_path);

    int server = socket(AF_UNIX, SOCK_STREAM, 0);
    if (server < 0) {
        perror("[receive_kuzu_json] socket");
        return;
    }

    sockaddr_un addr{};
    addr.sun_family = AF_UNIX;
    strncpy(addr.sun_path, sock_path, sizeof(addr.sun_path) - 1);

    if (bind(server, (sockaddr*)&addr, sizeof(addr)) < 0) {
        perror("[receive_kuzu_json] bind");
        close(server);
        return;
    }

    if (listen(server, 5) < 0) {
        perror("[receive_kuzu_json] listen");
        close(server);
        return;
    }

    while (true) {
        int client = accept(server, nullptr, nullptr);
        if (client < 0) {
            std::this_thread::sleep_for(std::chrono::milliseconds(50));
            continue;
        }

        char buf[4096];
        ssize_t n = read(client, buf, sizeof(buf)-1);
        if (n > 0) {
            buf[n] = '\0';
            printf("[VSS RECEIVED JSON]\n%s\n", buf);
        }
        close(client);
    }

    close(server);
}


// ======================= VISS IPC LISTENER ============================
// Handles GET / SET / SUBSCRIBE / UNSUBSCRIBE / GET_SCHEMA
// ======================================================================
void listen_viss_ipc()
{
    const char* socket_path = "/tmp/vss_ipc_socket";
    unlink(socket_path);

    int server = socket(AF_UNIX, SOCK_STREAM, 0);
    if (server < 0) {
        perror("[VISS IPC] socket");
        return;
    }

    sockaddr_un addr{};
    addr.sun_family = AF_UNIX;
    strncpy(addr.sun_path, socket_path, sizeof(addr.sun_path)-1);

    if (bind(server, (sockaddr*)&addr, sizeof(addr)) < 0) {
        perror("[VISS IPC] bind");
        close(server);
        return;
    }

    if (listen(server, 20) < 0) {
        perror("[VISS IPC] listen");
        close(server);
        return;
    }

    std::cout << "[VISS IPC] Listening on " << socket_path << std::endl;

    while (true)
    {
        int client = accept(server, nullptr, nullptr);
        if (client < 0) {
            std::this_thread::sleep_for(std::chrono::milliseconds(20));
            continue;
        }

        // handle client quickly in detached thread so accept loop remains responsive
        std::thread([client]() {
            char buf[4096];
            ssize_t n = read(client, buf, sizeof(buf)-1);
            std::string reply = "{}";

            if (n > 0) {
                buf[n] = '\0';
                std::string req(buf);
                std::cout << "[VISS IPC] Received: " << req << std::endl;

                // GET: "GET <path>"
                if (req.rfind("GET ", 0) == 0) {
                    std::string path = req.substr(4);
                    // trim
                    size_t s = path.find_first_not_of(" \t\r\n");
                    size_t e = path.find_last_not_of(" \t\r\n");
                    if (s == string::npos) path.clear();
                    else path = path.substr(s, e - s + 1);

                    auto latest = db.get_latest(path);
                    reply = to_string(latest.value) + "|" + latest.iso_timestamp;
                }
                // SET: "SET <path> <value>"
                else if (req.rfind("SET ", 0) == 0) {
                    std::string rest = req.substr(4);
                    // split at first space
                    size_t sp = rest.find(' ');
                    if (sp != string::npos) {
                        std::string path = rest.substr(0, sp);
                        std::string value = rest.substr(sp + 1);
                        // trim
                        auto trim = [](string &s) {
                            size_t a = s.find_first_not_of(" \t\r\n");
                            if (a==string::npos) { s.clear(); return; }
                            size_t b = s.find_last_not_of(" \t\r\n");
                            s = s.substr(a, b - a + 1);
                        };
                        trim(path); trim(value);

                        double val = 0.0;
                        try { val = stod(value); } catch(...) { val = 0.0; }
                        string iso = nowISO8601();
                        db.add_vss_sample(path, val, iso);
                        // optionally forward to kuzu also
                        send_to_kuzu(path, val, iso);

                        reply = string("ok|") + iso;
                    } else {
                        reply = "error|bad_set_format";
                    }
                }
                // SUBSCRIBE: "SUBSCRIBE <path>"
                else if (req.rfind("SUBSCRIBE ", 0) == 0) {
                    std::string path = req.substr(10);
                    (void)path;
                    reply = "SUB12345"; // dummy subscription id
                }
                // UNSUBSCRIBE: "UNSUBSCRIBE <subscriptionId>"
                else if (req.rfind("UNSUBSCRIBE ", 0) == 0) {
                    std::string sub = req.substr(12);
                    (void)sub;
                    reply = "OK";
                }
                // GET_SCHEMA: "GET_SCHEMA <prefix>"
                else if (req.rfind("GET_SCHEMA ", 0) == 0) {
                    std::string prefix = req.substr(11);
                    // delegate to SQLiteDB schema API
                    string json = db.get_schema_json(prefix);
                    reply = json;
                }
                else if(req == "READ_JSON"){
                
                }
                else {
                    reply = "error|unknown_command";
                }
            } else {
                reply = "error|no_data";
            }

            // send reply
            write(client, reply.c_str(), reply.size());
            close(client);
            std::cout << "[VISS IPC] Replied: " << reply << std::endl;
        }).detach();
    }

    close(server);
}


// ---------------------------- MAIN ----------------------------

int main()
{
    std::cout << "[MAIN] Starting services...\n";

    // Start Kuzu service
    start_kuzu_service();

    // Init SQLite DB (will create or open as per your sqlite-db.hpp behavior)
    if (!db.init("vss_hierarchical.db", 2)) {
        std::cerr << "[MAIN] Failed to init DB\n";
        return 1;
    }

    // Start kuzu JSON reply listener (detached thread)
    std::thread jsonThread(receive_kuzu_json);
    jsonThread.detach();

    // Start VISS IPC listener
    std::thread vissIPCThread(listen_viss_ipc);
    vissIPCThread.detach();

    std::cout << "[MAIN] Background listeners running.\n";

    // Read and process input file (keeps original logic — one line at a time)
    ifstream infile("input.txt");
    if (!infile.good()) {
        cerr << "input.txt not found\n";
        // still keep servers alive
    } else {
        std::cout << "[MAIN] Reading input.txt and converting raw data...\n";

        string line;
        while (getline(infile, line)) {
            RawData data;
            if (parseLine(line, data)) {
                Middleware_someipreq(data);
            }
            // keep your original 100ms delay
            std::this_thread::sleep_for(std::chrono::milliseconds(100));
        }
        std::cout << "[MAIN] Finished processing input.txt\n";
    }

    // Keep main alive forever so detached threads keep servicing
    while (true) {
        std::this_thread::sleep_for(std::chrono::seconds(1));
    }

    return 0;
}

