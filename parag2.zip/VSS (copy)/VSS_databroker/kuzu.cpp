#include <iostream>
#include <unistd.h>
#include <sys/un.h>
#include <sys/socket.h>
#include <cstring>
#include <cstdlib>
#include <cstdio>
#include <ctime>
#include <sstream>
#include <map>

#include "include/kuzu.hpp"

using namespace std;
using namespace kuzu::main;

class KuzuManager {
public:
    unique_ptr<Database> db;
    unique_ptr<Connection> conn;

    KuzuManager() {
        SystemConfig cfg;
        db   = make_unique<Database>("vss_latest.kuzu", cfg);
        conn = make_unique<Connection>(db.get());
        initSchema();
    }

    inline void execFast(const char* q) {
        auto res = conn->query(q);
        if (!res->isSuccess()) {
            fprintf(stderr, "[Kuzu ERROR] %s\n", res->getErrorMessage().c_str());
        }
    }

    void initSchema() {
        execFast(
            "CREATE NODE TABLE IF NOT EXISTS VSSNode("
            " full_path STRING PRIMARY KEY,"
            " value DOUBLE,"
            " timestamp_iso STRING"
            ");"
        );

        execFast("CREATE REL TABLE IF NOT EXISTS HAS(FROM VSSNode TO VSSNode);");
    }

    // Build hierarchy
    void createHierarchy(const char* fullPath) {
        char pathBuf[256];
        strncpy(pathBuf, fullPath, sizeof(pathBuf));

        char accum[256] = {0};
        char parent[256] = {0};
        char segment[128];

        const char* p = pathBuf;
        int ai = 0;

        while (*p) {
            int si = 0;

            while (*p && *p != '.') {
                segment[si++] = *p++;
            }
            segment[si] = '\0';
            if (*p == '.') p++;

            if (ai != 0) accum[ai++] = '.';
            for (int j = 0; segment[j]; j++) accum[ai++] = segment[j];
            accum[ai] = '\0';

            char qnode[512];
            snprintf(qnode, sizeof(qnode),
                     "MERGE (n:VSSNode {full_path:'%s'});", accum);
            execFast(qnode);

            if (parent[0] != '\0') {
                char qrel[768];
                snprintf(qrel, sizeof(qrel),
                         "MATCH (p:VSSNode {full_path:'%s'}), "
                         "(c:VSSNode {full_path:'%s'}) MERGE (p)-[:HAS]->(c);",
                         parent, accum);
                execFast(qrel);
            }
            strcpy(parent, accum);
        }
    }

    // UPDATE
    inline void updateLatest(const char* path, double value, const char* iso)
    {
        createHierarchy(path);

        char q[2048];
        snprintf(q, sizeof(q),
            "MERGE (n:VSSNode {full_path:'%s'}) "
            "SET n.value=%f, n.timestamp_iso='%s';",
            path, value, iso);

        execFast(q);
        printf("[UPDATE] %s = %.3f @ %s\n", path, value, iso);
    }

    // ---- JSON Builder (INSIDE CLASS) ----
    string buildJson() {
        auto result = conn->query(
            "MATCH (n:VSSNode) "
            "RETURN n.full_path, n.value, n.timestamp_iso "
            "ORDER BY n.full_path;"
        );

        struct Node {
            double value = 0;
            string ts;
            map<string, Node> children;
            bool hasData = false;
        };

        Node root;

        while (result->hasNext()) {
            auto row = result->getNext();
            string path  = row->getValue(0)->getValue<string>();
            double val   = row->getValue(1)->getValue<double>();
            string ts    = row->getValue(2)->getValue<string>();

            vector<string> parts;
            string seg;
            stringstream ss(path);
            while (getline(ss, seg, '.')) parts.push_back(seg);

            Node* curr = &root;
            for (auto& p : parts)
                curr = &curr->children[p];

            curr->value = val;
            curr->ts = ts;
            curr->hasData = true;
        }

        function<void(const Node&, int, std::stringstream&)> dumpNode =
            [&](const Node& node, int indent, std::stringstream &out) {
                auto it = node.children.begin();
                while (it != node.children.end()) {
                    for (int i = 0; i < indent; i++) out << "  ";
                    out << "\"" << it->first << "\": ";

                    const Node &child = it->second;

                    if (child.children.empty()) {
                        out << "{ \"value\": " << child.value
                            << ", \"timestamp\": \"" << child.ts << "\" }";
                    } else {
                        out << "{\n";
                        dumpNode(child, indent + 1, out);
                        out << "\n";
                        for (int i = 0; i < indent; i++) out << "  ";
                        out << "}";
                    }

                    ++it;
                    if (it != node.children.end()) out << ",\n";
                }
            };

        std::stringstream out;
        out << "{\n";
        dumpNode(root, 1, out);
        out << "\n}\n";
        return out.str();
    }

    void sendJsonToClient(const std::string& json) {
        const char* replySock = "/tmp/kuzu_vss_reply.sock";

        int sock = socket(AF_UNIX, SOCK_STREAM, 0);
        if (sock < 0) return;

        sockaddr_un addr{};
        addr.sun_family = AF_UNIX;
        strncpy(addr.sun_path, replySock, sizeof(addr.sun_path) - 1);

        if (connect(sock, (sockaddr*)&addr, sizeof(addr)) == 0) {
            write(sock, json.c_str(), json.size());
        }

        close(sock);
    }

    void sendJsonDump() {
        string json = buildJson();
        sendJsonToClient(json);
    }
};   // <-- FIXED: class ends HERE


// ------------------------ MAIN ------------------------

int main() {
    remove("vss_latest.kuzu");
    remove("vss_latest.kuzu.wal");

    const char* sock_path = "/tmp/kuzu_vss.sock";
    unlink(sock_path);

    int server = socket(AF_UNIX, SOCK_STREAM, 0);

    sockaddr_un addr{};
    addr.sun_family = AF_UNIX;
    strncpy(addr.sun_path, sock_path, sizeof(addr.sun_path) - 1);

    bind(server, (sockaddr*)&addr, sizeof(addr));
    listen(server, 50);

    printf("[KuzuService] FAST MODE running at %s\n", sock_path);

    KuzuManager kuzu;
    char buf[512];
    long lastDump = time(NULL);

    while (true) {
        long now = time(NULL);
        if (now - lastDump >= 5) {
            kuzu.sendJsonDump();
            lastDump = now;
        }

        fd_set fds;
        FD_ZERO(&fds);
        FD_SET(server, &fds);

        struct timeval tv = {0, 50000};

        int ready = select(server + 1, &fds, NULL, NULL, &tv);

        if (ready > 0 && FD_ISSET(server, &fds)) {
            int client = accept(server, nullptr, nullptr);
            if (client >= 0) {
                int n = read(client, buf, sizeof(buf) - 1);
                if (n > 0) {
                    buf[n] = '\0';

                    // Format: path|value|ISO_TIMESTAMP
                    char* path = strtok(buf, "|");
                    char* valStr = strtok(NULL, "|");
                    char* iso = strtok(NULL, "|");

                    if (path && valStr && iso) {
                        kuzu.updateLatest(path, atof(valStr), iso);
                    }
                }
                close(client);
            }
        }
    }

    close(server);
    return 0;
}

