#include <iostream>
#include <cstring>
#include <thread>
#include <chrono>
#include "dds/dds.h"
#include <nlohmann/json.hpp>

extern "C" {
#include "vss_topics.h"
}

using json = nlohmann::json;

#define VISS_REQ_TOPIC "VISSRequest"
#define VISS_RES_TOPIC "VISSResponse"

// -----------------------------------------------------------------------------
// SEND GET REQUEST
// -----------------------------------------------------------------------------
void sendGetRequest(dds_entity_t writer, const std::string &path)
{
    VISSRequest req{};
    json j;
    j["action"] = "get";
    j["path"] = path;
    j["requestId"] = "123";

    std::string msg = j.dump();
    strncpy(req.json, msg.c_str(), sizeof(req.json) - 1);

    std::cout << "[DDS] Sending GET request: " << msg << "\n";
    dds_write(writer, &req);
}

// -----------------------------------------------------------------------------
// SEND SET REQUEST
// -----------------------------------------------------------------------------
void sendSetRequest(dds_entity_t writer, const std::string &path, double value)
{
    VISSRequest req{};
    json j;
    j["action"] = "set";
    j["path"] = path;
    j["value"] = value;
    j["requestId"] = "SET123";

    std::string msg = j.dump();
    strncpy(req.json, msg.c_str(), sizeof(req.json) - 1);

    std::cout << "[DDS] Sending SET request: " << msg << "\n";
    dds_write(writer, &req);
}

// -----------------------------------------------------------------------------
// SEND SUBSCRIBE REQUEST
// -----------------------------------------------------------------------------
void sendSubscribeRequest(dds_entity_t writer, const std::string &path)
{
    VISSRequest req{};
    json j;
    j["action"] = "subscribe";
    j["path"] = path;
    j["filter"]["interval"] = 1000;
    j["requestId"] = "SUB123";

    std::string msg = j.dump();
    strncpy(req.json, msg.c_str(), sizeof(req.json) - 1);

    std::cout << "[DDS] Sending SUBSCRIBE request: " << msg << "\n";
    dds_write(writer, &req);
}

// -----------------------------------------------------------------------------
// SEND UNSUBSCRIBE REQUEST
// -----------------------------------------------------------------------------
void sendUnsubscribeRequest(dds_entity_t writer, const std::string &subscriptionId)
{
    VISSRequest req{};
    json j;
    j["action"] = "unsubscribe";
    j["subscriptionId"] = subscriptionId;
    j["requestId"] = "UNSUB123";

    std::string msg = j.dump();
    strncpy(req.json, msg.c_str(), sizeof(req.json) - 1);

    std::cout << "[DDS] Sending UNSUBSCRIBE request: " << msg << "\n";
    dds_write(writer, &req);
}

// -----------------------------------------------------------------------------
// WAIT FOR RESPONSE
// -----------------------------------------------------------------------------
void listenResponse(dds_entity_t reader)
{
    std::cout << "[DDS] Waiting for VISS response...\n";

    while (true)
    {
        VISSResponse res{};
        void* samples[1] = { &res };
        dds_sample_info_t info{};

        dds_return_t rc = dds_take(reader, samples, &info, 1, 1);

        if (rc > 0 && info.valid_data)
        {
            try {
                json j = json::parse(res.json);
                std::cout << "\n[VISS-RESPONSE]\n" << j.dump(4) << "\n\n";
            } catch (...) {
                std::cerr << "Bad JSON: " << res.json << "\n";
            }
            break;
        }

        std::this_thread::sleep_for(std::chrono::milliseconds(100));
    }
}

// -----------------------------------------------------------------------------
// MAIN
// -----------------------------------------------------------------------------
int main()
{
    std::cout << "[DDS-CLIENT] Starting test client...\n";

    dds_entity_t participant =
        dds_create_participant(DDS_DOMAIN_DEFAULT, nullptr, nullptr);

    if (participant < 0) {
        std::cerr << "Failed to create participant.\n";
        return 1;
    }

    dds_entity_t req_topic =
        dds_create_topic(participant, &VISSRequest_desc, VISS_REQ_TOPIC, nullptr, nullptr);

    dds_entity_t req_writer =
        dds_create_writer(participant, req_topic, nullptr, nullptr);

    dds_entity_t res_topic =
        dds_create_topic(participant, &VISSResponse_desc, VISS_RES_TOPIC, nullptr, nullptr);

    dds_entity_t res_reader =
        dds_create_reader(participant, res_topic, nullptr, nullptr);

    std::cout << "Waiting 2 seconds for discovery...\n";
    std::this_thread::sleep_for(std::chrono::seconds(2));

    // -------------------------------------------------------------------------
    // TEST 1: GET
    // -------------------------------------------------------------------------
    sendGetRequest(req_writer, "Vehicle.Speed");
    listenResponse(res_reader);

    std::this_thread::sleep_for(std::chrono::milliseconds(5000));  // 0.5 sec gap

    // -------------------------------------------------------------------------
    // TEST 2: SET
    // -------------------------------------------------------------------------
    sendSetRequest(req_writer, "Vehicle.Speed", 55.0);
    listenResponse(res_reader);

    std::this_thread::sleep_for(std::chrono::milliseconds(5000));  // 0.5 sec gap

    // -------------------------------------------------------------------------
    // TEST 3: SUBSCRIBE
    // -------------------------------------------------------------------------
    sendSubscribeRequest(req_writer, "Vehicle.Speed");
    listenResponse(res_reader);

    std::this_thread::sleep_for(std::chrono::milliseconds(5000));  // 0.5 sec gap

    // -------------------------------------------------------------------------
    // TEST 4: UNSUBSCRIBE
    // -------------------------------------------------------------------------
    sendUnsubscribeRequest(req_writer, "SUB123-ID");
    listenResponse(res_reader);

    dds_delete(participant);
    return 0;
}
